package Server;
import java.io.IOException;
import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.concurrent.ExecutionException;

/**
 * @author Hao
 * @date 05/23/2016
 * RMI-DSMS, COMP 6231 - DSMS Interface
 */

public interface ClinicServerInterface extends Remote{
	public String createDRecord(String userID, String FirstName, String LastName, String address, String phoneNb, String specialization, String locat) throws RemoteException, IOException, InterruptedException, ExecutionException;
	public String createNRecord(String userID, String FirstName, String LastName, String designation, String status, String statusDate) throws RemoteException, IOException, InterruptedException, ExecutionException;
	public String getRecordCounts(String userID, String recordType) throws RemoteException, IOException;
	public String editRecord(String userID, String recordID, String fieldName, String newValue) throws RemoteException, IOException;
	public boolean ManagerCheck(String id, String password) throws RemoteException;
//	public void registerForCallback(CallbackClientInterface callbackClientObject) throws RemoteException;
//	public void unregisterForCallback(CallbackClientInterface callbackClientObject) throws RemoteException;
}
