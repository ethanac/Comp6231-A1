package Server;

public enum Location {
	Montreal, Laval, DDO
}
