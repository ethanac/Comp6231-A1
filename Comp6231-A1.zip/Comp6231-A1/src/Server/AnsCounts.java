package Server;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;

public class AnsCounts implements Runnable{
	public ClinicServer cs = null;
	private int port;
	
	public AnsCounts(ClinicServer cs, int p){
		this.cs = cs;
		port = p;
	}
	public void run(){
		ansCounts();
	}
	/**
	 * Reply to the counts request using UDP.
	 */
	private void ansCounts(){
		DatagramSocket aSocket = null;
		try{
		  aSocket = new DatagramSocket(port);
		  //byte[] buffer = new byte[1000];
		  while(true){
			  String s = "";
			  byte[] buffer = new byte[1000];
			  DatagramPacket request = new DatagramPacket(buffer, buffer.length);
			  DatagramPacket reply = null;
			  aSocket.receive(request);
			  s = new String(request.getData()).trim();
			  if(s.equals("D")){
				  String content = cs.getDCounts()+"";
				  reply = new DatagramPacket(content.getBytes(), content.length(), request.getAddress(), request.getPort());
			  }
			  else if(s.equals("N")){
				  String content = cs.getNCounts()+"";
				  reply = new DatagramPacket(content.getBytes(), content.length(), request.getAddress(), request.getPort());
			  }
			  else if(s.equals("ADDD")){
				  cs.updateTotalDCounts();
				  String content = cs.getTotalDCounts()+"";
				  reply = new DatagramPacket(content.getBytes(), content.length(), request.getAddress(), request.getPort());
			  }
			  else if(s.equals("ADDN")){
				  cs.updateTotalNCounts();
				  String content = cs.getTotalNCounts()+"";
				  reply = new DatagramPacket(content.getBytes(), content.length(), request.getAddress(), request.getPort());
			  }
			  aSocket.send(reply);
		  }
		}
		catch(SocketException e){System.out.println("Socket: " + e.getMessage());}
		catch(IOException e){System.out.println("IO: " + e.getMessage());}
		finally{if(aSocket != null) aSocket.close();}
	}
}
